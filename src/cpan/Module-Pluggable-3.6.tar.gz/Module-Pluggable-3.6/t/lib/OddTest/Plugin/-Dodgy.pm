package OddFiles::Plugin::Dodgy;

sub new {}

1;
